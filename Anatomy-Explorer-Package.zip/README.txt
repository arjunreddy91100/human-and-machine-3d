HUMAN + MACHINE — INTERACTIVE 3D ANATOMY

Open Anatomy-Explorer.html in desktop Chrome. This offline file contains the complete model; no installation or web server is needed. Enable WebGL if required by your browser.

The human (125 pieces) and a BMW R 1250 GS Adventure-inspired motorcycle (70 components) appear side by side. Scroll inward to separate parts, outward to reassemble. Drag to orbit; hover for names and functions; click to keep the description selected. Use Explore to focus on a model, All systems to filter, and Find a component to select by name. The slider controls separation directly. Reset view reassembles the selected view. On touchscreens, pinch to zoom and tap to select.

Human-and-Motorcycle.glb contains 195 named meshes and an Explode and reassemble animation. Node extras contain object, system, description and offset. Standard animation-capable GLB viewers can play the animation. Automatic zoom explosion and hover labels require the supplied HTML viewer.

This is original, schematic educational artwork. The human retains the previous simplified anatomy. The motorcycle is an R 1250 GS Adventure-inspired interpretation, not official BMW CAD, an exact model-year replica, or a repair guide. Its internal mechanisms, dimensions and details are simplified. Windscreen is opaque blue for reliable rendering. Both models are approximately proportioned, not dimensionally certified.

Reference for motorcycle architecture: BMW Media Information, November 2018, The new BMW R 1250 R, R 1250 RS and R 1250 GS Adventure:
https://www.invelt.com/UserFiles/File/1667732004The-new-BMW-R-1250-R-the-new-BMW-R-1250-RS-and-the-new-BMW-R-1250-GS-Adventure-2.PDF
BMW Telelever explanation:
https://www.bmwmotorcycles.com/en/engineering/detail/suspension/telelever.html

Source: build.py is the original human generator. add_motorcycle.py builds the combined model using Python standard library. update_viewer.py creates the updated viewer using viewer-template.html. Place source files together and run add_motorcycle.py followed by update_viewer.py; output appears in combined/.
