import pathlib,math,json,struct,base64,zipfile
P=pathlib.Path(__file__).parent
original=(P/'build.py').read_text();exec(original.split('# Binary glTF')[0])
for p in parts:
 p['object']='Human';p['center'][0]-=1.5
 p['v']=[v-1.5 if i%3==0 else v for i,v in enumerate(p['v'])]
 p['offset']=[v*.52 for v in p['offset']]
colors.update({'Wheels & brakes':'#c4a064','Engine & drivetrain':'#959fa9','Chassis & suspension':'#b9c6ce','Bodywork':'#e5e9ee','Cockpit & lights':'#8bc5d9','Luggage':'#a9b4bc'})
START=len(parts)
def add(name,c,v,n,idx,sys,color,desc,off=None):
 parts.append(dict(name=name,center=c,v=v,n=n,i=idx,system=sys,color=color or colors[sys],description=desc,object='Motorcycle',offset=off or [c[0]*.36,(c[1]-.6)*.8,c[2]*1.6]))
def box(name,c,s,sys,desc,color=None,off=None):
 v=[];n=[];idx=[]
 for axis in range(3):
  for sign in [-1,1]:
   a=(axis+1)%3;b=(axis+2)%3;start=len(v)//3
   for u,w in [(-1,-1),(1,-1),(1,1),(-1,1)]:
    q=list(c);q[axis]+=sign*s[axis]/2;q[a]+=u*s[a]/2;q[b]+=w*s[b]/2;v+=q;nn=[0,0,0];nn[axis]=sign;n+=nn
   idx += [start,start+1,start+2,start,start+2,start+3]
 add(name,c,v,n,idx,sys,color,desc,off)
def rod(name,a,b,r,sys,desc,color=None):
 ell(name,[0,0,0],[r,1,r],sys,desc,(a,b));p=parts[-1];p['object']='Motorcycle';p['color']=color or colors[sys];p['offset']=[p['center'][0]*.36,(p['center'][1]-.6)*.8,p['center'][2]*1.6]
def torus(name,c,R,r,depth,sys,desc,color=None,off=None):
 v=[];n=[];idx=[]
 for j in range(65):
  a=j*2*math.pi/64
  for k in range(13):
   b=k*2*math.pi/12;v += [c[0]+(R+r*math.cos(b))*math.cos(a),c[1]+(R+r*math.cos(b))*math.sin(a),c[2]+depth*math.sin(b)];n += [math.cos(b)*math.cos(a),math.cos(b)*math.sin(a),math.sin(b)]
 for j in range(64):
  for k in range(12):
   a=j*13+k;b=a+13;idx += [a,a+1,b,b,a+1,b+1]
 add(name,c,v,n,idx,sys,color,desc,off)
def merge(start,name,off=None):
 group=parts[start:];p=group[0];p['name']=name
 for q in group[1:]:
  shift=len(p['v'])//3;p['v']+=q['v'];p['n']+=q['n'];p['i'] += [a+shift for a in q['i']]
 parts[start:]=[p]
 if off:p['offset']=off
# longitudinal axis X; front toward +X; wheel axes Z
for x,label,R in [(-.70,'Rear',.285),(.78,'Front',.315)]:
 c=[x,R+.055,0];off=[-.46 if x<0 else .46,-.12,0]
 torus(label+' tire',c,R-.023,.058,.083,'Wheels & brakes','Provides traction, absorbs small surface irregularities, and carries load.','#252c35',off)
 torus(label+' spoked wheel rim',c,R-.087,.018,.067,'Wheels & brakes','Holds the tire and distributes spoke loads.','#c7a35c',[off[0],-.12,.21])
 k=len(parts)
 for j in range(24):
  a=2*math.pi*j/24;rod(label+' spokes',[x,.0+c[1],(-1 if j%2 else 1)*.045],[x+(R-.09)*math.cos(a),c[1]+(R-.09)*math.sin(a),(-1 if j%2 else 1)*.025],.004,'Wheels & brakes','Tensioned spokes connect the hub and rim.','#bac4ca')
 merge(k,label+' cross-spoke assembly',[off[0],-.12,-.20])
 rod(label+' wheel hub',[x,c[1],-.07],[x,c[1],.07],.052,'Wheels & brakes','Supports the wheel bearings and axle.')
 for z in ([.095,-.095] if label=='Front' else [.105]):
  torus(label+' brake disc '+('near' if z>0 else 'far'),[x,c[1],z],.125,.03,.008,'Wheels & brakes','Brake pads clamp the disc to slow the wheel.','#aab6be',[off[0],-.12,.40 if z>0 else -.4])
  box(label+' brake caliper '+('near' if z>0 else 'far'),[x-.115,c[1]+.065,z],[.065,.095,.044],'Wheels & brakes','Hydraulic pistons press the pads against the brake disc.','#b89951')
# large tank, beak, stepped saddle, windshield and luggage
ell('Adventure fuel tank',[.08,.91,0],[.34,.21,.23],'Bodywork','Stores fuel above the engine; the large tank is a signature Adventure feature.');parts[-1].update(object='Motorcycle',color='#e3e7e8',offset=[.03,.6,0])
for z in [-.21,.21]:
 box('Tank side panel '+str(z),[.18,.87,z],[.4,.18,.035],'Bodywork','Protective exterior panel beside the fuel tank.','#28629a',[.06,.34,z*2.4])
 box('Rally red accent '+str(z),[.04,.945,z*1.09],[.19,.035,.012],'Bodywork','Decorative adventure-style bodywork stripe.','#d95149',[.06,.34,z*2.4])
box('Rider saddle',[-.31,.91,0],[.42,.10,.29],'Bodywork','Supports the rider in an upright touring position.','#222d3c',[-.1,.55,0])
box('Passenger saddle',[-.64,1.00,0],[.26,.10,.29],'Bodywork','Raised rear seating area for a passenger.','#303c4c',[-.3,.7,0])
box('Front beak',[.69,.89,0],[.41,.045,.2],'Bodywork','Adventure-style front bodywork above the wheel.','#e8e9df',[.4,.4,0])
box('Front mudguard',[.77,.725,0],[.38,.035,.16],'Bodywork','Deflects road spray from the front wheel.','#293440',[.48,.15,0])
box('Windscreen',[.52,1.255,0],[.025,.37,.30],'Cockpit & lights','Deflects airflow away from the rider; rendered as a blue solid surface.','#91bac6',[.35,.7,0])
box('Headlight housing',[.625,1.045,0],[.13,.13,.27],'Cockpit & lights','Houses the forward lighting assembly.','#323f4a',[.46,.35,0])
box('LED headlight face',[.696,1.045,0],[.012,.075,.22],'Cockpit & lights','Illuminates the road ahead.','#dcefff',[.6,.35,0])
box('TFT instrument display',[.385,1.157,0],[.03,.083,.14],'Cockpit & lights','Displays speed, riding information, and motorcycle status.','#4a95b8',[.13,.62,.22])
rod('Handlebar',[.29,1.16,-.36],[.29,1.16,.36],.015,'Cockpit & lights','Transfers rider steering input to the front assembly.')
for z in [-.34,.34]:
 box('Handguard '+str(z),[.35,1.17,z],[.09,.075,.16],'Cockpit & lights','Shields the rider’s hands from wind and debris.','#dde5e6')
 rod('Mirror stalk '+str(z),[.29,1.18,z],[.26,1.34,z*1.15],.009,'Cockpit & lights','Supports the rear-view mirror.')
 box('Rear-view mirror '+str(z),[.26,1.355,z*1.15],[.04,.08,.11],'Cockpit & lights','Provides a view of traffic behind.','#8499a5')
 box('Aluminum pannier '+str(z),[-.68,.77,z*1.15],[.4,.32,.235],'Luggage','Removable side case for touring luggage.','#aebbc4',[-.38,.22,z*2.6])
 box('Pannier lid '+str(z),[-.68,.943,z*1.15],[.42,.03,.25],'Luggage','Closes the touring side case.','#566778',[-.38,.5,z*2.6])
box('Rear luggage rack',[-.88,1.04,0],[.25,.035,.33],'Luggage','Mounting platform for luggage behind the passenger.','#8899a5')
box('Tail lamp',[-.91,.94,0],[.035,.045,.14],'Cockpit & lights','Signals braking and marks the rear of the motorcycle.','#f3474e')
# Boxer engine and transmission
box('Engine crankcase',[.01,.52,0],[.38,.28,.28],'Engine & drivetrain','Central engine housing around the crankshaft.','#737f89',[.08,-.17,0])
for z in [-1,1]:
 box(('Left' if z>0 else 'Right')+' boxer cylinder',[.10,.56,z*.23],[.22,.17,.22],'Engine & drivetrain','Opposed cylinders extend horizontally from the central crankcase.','#a9b2b8',[.05,-.05,z*.54])
 box(('Left' if z>0 else 'Right')+' cylinder-head cover',[.10,.56,z*.366],[.24,.18,.055],'Engine & drivetrain','Protects the cylinder-head valve mechanism.','#424e59',[.05,.0,z*.9])
 k=len(parts)
 for j in range(6):box('Cylinder cooling fin',[.10,.493+j*.025,z*.255],[.235,.006,.23],'Engine & drivetrain','External fins increase surface area for heat transfer.','#5b6975')
 merge(k,('Left' if z>0 else 'Right')+' cylinder fin assembly',[.05,-.05,z*.6])
 box('Radiator '+str(z),[.35,.775,z*.195],[.12,.19,.06],'Engine & drivetrain','Transfers heat from engine coolant to passing air.','#3f515e',[.3,.14,z*.7])
 k=len(parts)
 for j in range(3):rod('Crash protection bar',[.28-j*.22,.43,z*.41],[.28-j*.22,.79,z*.41],.012,'Chassis & suspension','Tubular protection around the engine and bodywork.')
 rod('Crash bar lower rail',[-.16,.43,z*.41],[.28,.43,z*.41],.012,'Chassis & suspension','Tubular protection around the engine and bodywork.')
 rod('Crash bar upper rail',[-.16,.79,z*.41],[.28,.79,z*.41],.012,'Chassis & suspension','Tubular protection around the engine and bodywork.')
 merge(k,'Engine crash cage '+str(z),[0,0,z*.85])
 rod('Exhaust header '+str(z),[.23,.50,z*.27],[.24,.30,z*.21],.026,'Engine & drivetrain','Carries exhaust gases from the cylinder head.','#af9476')
box('Gearbox',[-.27,.52,0],[.20,.20,.24],'Engine & drivetrain','Changes the ratio between engine speed and rear-wheel speed.','#697984',[-.27,-.23,0])
rod('Paralever swingarm and shaft housing',[-.30,.49,-.105],[-.70,.34,-.105],.045,'Chassis & suspension','Rear suspension arm enclosing the shaft-drive path.','#9ba9b3')
rod('Final-drive housing',[-.70,.34,-.16],[-.70,.34,-.08],.075,'Engine & drivetrain','Turns shaft-drive rotation to drive the rear wheel.')
rod('Rear suspension strut',[-.52,.47,-.015],[-.34,.77,-.015],.029,'Chassis & suspension','Spring and damper assembly controlling rear suspension movement.','#dcbd68')
for z in [-.087,.087]:
 rod('Front fork leg '+str(z),[.78,.37,z],[.48,1.08,z],.022,'Chassis & suspension','Guides the front wheel and steering assembly.','#b9c8cf')
 rod('Telelever wishbone arm '+str(z),[.11,.58,z*1.6],[.64,.65,z*.7],.023,'Chassis & suspension','Links the front wheel assembly to the chassis; separates suspension and steering functions.')
 rod('Rear subframe '+str(z),[-.22,.60,z],[-.85,.94,z],.017,'Chassis & suspension','Supports the seat and rear luggage.','#b73241')
 rod('Main frame upper rail '+str(z),[-.20,.76,z],[.45,1.04,z],.022,'Chassis & suspension','Structural connection between the steering head and engine region.','#b73241')
rod('Front central suspension strut',[.21,.62,0],[.29,.90,0],.029,'Chassis & suspension','Central spring and damper for the Telelever front suspension.','#d7b95d')
box('Engine skid plate',[.05,.32,0],[.45,.04,.34],'Chassis & suspension','Protects the underside of the engine from debris.','#b7c4ca',[0,-.3,0])
rod('Exhaust silencer',[-.77,.64,.25],[-.38,.52,.25],.066,'Engine & drivetrain','Reduces exhaust noise before gases leave the system.','#aeb6ba')
box('Airbox',[-.09,.77,0],[.20,.12,.19],'Engine & drivetrain','Holds the intake air filter and supplies filtered air to the engine.','#303d49',[0,.34,-.38])
box('Battery',[-.36,.77,0],[.105,.10,.13],'Cockpit & lights','Supplies electrical energy for starting and onboard systems.','#465665',[-.1,.38,.37])
# shift motorcycle to right, keep explosion relative to its own center
for p in parts[START:]:
 p['center'][0]+=.85;p['v']=[v+.85 if i%3==0 else v for i,v in enumerate(p['v'])]
# Use original exporter with object metadata; write to a separate generation folder.
OUT=P/'combined';OUT.mkdir(exist_ok=True);P0=P;P=OUT
exporter='# Binary glTF'+original.split('# Binary glTF',1)[1]
exporter=exporter.replace("['system','description','offset']","['system','description','offset','object']")
exec(exporter)
(P/'human-anatomy.glb').rename(P/'Human-and-Motorcycle.glb')
(P/'components.json').write_text(json.dumps([{k:v for k,v in p.items() if k not in ['v','n','i']} for p in parts],indent=2))
print('Human:',START,'Motorcycle:',len(parts)-START)
