import math,json,struct,base64,pathlib,zipfile
P=pathlib.Path(__file__).parent
parts=[]
colors={'Skeleton':'#eee2c2','Muscles':'#bf5264','Organs':'#be789b','Respiratory':'#79b5cb','Digestive':'#d89665','Urinary':'#a283cc','Nervous':'#e8ba7c','Circulatory':'#d63855'}
def ell(name,c,s,system,desc,axis=None):
 v=[]; n=[]; idx=[]
 # oriented ellipsoids with long local Y axis
 if axis:
  a,b=axis;c=[(a[i]+b[i])/2 for i in range(3)];d=[b[i]-a[i] for i in range(3)];L=math.sqrt(sum(x*x for x in d)); y=[x/L for x in d]; ref=[0,0,1];x=[y[1],-y[0],0];xl=math.sqrt(sum(t*t for t in x));x=[t/xl for t in x] if xl else [1,0,0];z=[x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]];s=[s[0],L/2+s[0]*.3,s[2]]
 else:x,y,z=[1,0,0],[0,1,0],[0,0,1]
 for j in range(17):
  t=math.pi*j/16
  for k in range(25):
   f=2*math.pi*k/24;q=[math.sin(t)*math.cos(f),math.cos(t),math.sin(t)*math.sin(f)];vv=[q[i]*s[i] for i in range(3)];nn=[q[i]/s[i] for i in range(3)];ln=math.sqrt(sum(a*a for a in nn));v.extend([c[i]+x[i]*vv[0]+y[i]*vv[1]+z[i]*vv[2] for i in range(3)]);n.extend([(x[i]*nn[0]+y[i]*nn[1]+z[i]*nn[2])/ln for i in range(3)])
 for j in range(16):
  for k in range(24):
   a=j*25+k;b=a+25;idx.extend([a,a+1,b,b,a+1,b+1])
 side=1 if c[0]>=0 else -1
 off=[c[0]*1.15+side*.14,(c[1]-.95)*.65,c[2]*2.5]
 if system not in ['Skeleton','Muscles']:off[2]+=.55
 if system=='Muscles':off[0]+=side*.22;off[2]+=.18
 parts.append(dict(name=name,center=c,system=system,description=desc,color=colors[system],offset=off,v=v,n=n,i=idx))
def bone(name,a,b,r=.025):ell(name,[0,0,0],[r,1,r],'Skeleton','Supports the body and provides attachment for muscles.',(a,b))
ell('Skull',[0,1.72,0],[.105,.135,.09],'Skeleton','Protects the brain and forms the framework of the head.')
ell('Mandible',[0,1.625,.035],[.079,.035,.064],'Skeleton','Lower jaw; moves during chewing and speech.')
ell('Brain',[0,1.765,.015],[.092,.079,.079],'Nervous','Coordinates sensation, movement, thought, and many body functions.')
for j in range(20):ell('Vertebra %02d (schematic)'%(j+1),[0,.94+j*.032,-.06],[.026,.014,.024],'Skeleton','A segment of the spinal column. This model simplifies vertebral count and shape.')
bone('Cervical spine',[0,1.55,-.03],[0,1.63,-.03],.03)
ell('Pelvis',[0,.91,-.018],[.145,.09,.072],'Skeleton','Transfers upper-body weight to the legs and supports pelvic organs.')
bone('Sternum',[0,1.22,.092],[0,1.47,.092],.022)
for side,label in [(-1,'Right'),(1,'Left')]:
 bone(label+' clavicle',[side*.025,1.49,.05],[side*.19,1.49,.015],.016)
 ell(label+' scapula',[side*.13,1.41,-.082],[.07,.092,.018],'Skeleton','Shoulder blade; anchors muscles and connects with the upper arm.')
 for j in range(8):
  # each rib is a separate curved mesh, assembled from overlapping short ellipsoids
  y=1.23+j*.032; pts=[[side*.025,y,-.067],[side*.11,y+.035,-.055],[side*(.15+(3-abs(j-3))*.009),y+.016,.01],[side*.12,y-.022,.085],[side*.027,y-.025,.095]]
  start=len(parts)
  for k in range(4):bone(label+' rib '+str(j+1),pts[k],pts[k+1],.009)
  group=parts[start:];p=group[0];p['description']='Curved bone helping protect the chest organs. Eight representative ribs per side are shown.'
  for q in group[1:]:shift=len(p['v'])//3;p['v']+=q['v'];p['n']+=q['n'];p['i'] += [a+shift for a in q['i']]
  parts[start:]=[p]
 shoulder=[side*.205,1.46,0];elbow=[side*.30,1.16,0];wrist=[side*.355,.915,.015]
 bone(label+' humerus',shoulder,elbow,.026)
 bone(label+' radius',[side*.31,1.15,.019],[side*.37,.92,.023],.014)
 bone(label+' ulna',[side*.286,1.15,-.014],[side*.34,.92,-.009],.013)
 ell(label+' hand',[side*.375,.85,.017],[.04,.065,.022],'Skeleton','Simplified hand region representing the palm bones.')
 for f in range(5):bone(label+' finger '+str(f+1),[side*(.343+f*.015),.815,.017],[side*(.346+f*.019),.74+abs(f-2)*.012,.022],.007)
 hip=[side*.082,.9,0];knee=[side*.093,.5,.015];ankle=[side*.095,.115,0]
 bone(label+' femur',hip,knee,.035)
 bone(label+' tibia',knee,ankle,.026)
 bone(label+' fibula',[side*.13,.49,-.008],[side*.127,.12,-.008],.013)
 ell(label+' patella',[side*.093,.5,.05],[.032,.037,.015],'Skeleton','Kneecap; protects the front of the knee joint.')
 ell(label+' foot',[side*.096,.066,.065],[.048,.034,.105],'Skeleton','Simplified foot region; supports standing and propulsion.')
 for name,c,s,desc in [('Deltoid',[.211,1.44,.012],[.058,.086,.057],'Raises the arm at the shoulder.'),('Pectoralis major',[.095,1.395,.115],[.093,.075,.024],'Moves the arm across the chest.'),('Biceps brachii',[.255,1.30,.042],[.041,.12,.035],'Flexes the elbow and rotates the forearm.'),('Triceps brachii',[.252,1.30,-.04],[.04,.125,.03],'Extends the elbow.'),('Forearm muscles',[.329,1.035,.026],[.03,.10,.03],'Control wrist and finger movement.'),('External oblique',[.111,1.13,.06],[.045,.105,.033],'Rotates and bends the trunk.'),('Quadriceps',[.092,.706,.053],[.065,.172,.05],'Extends the knee.'),('Hamstrings',[.092,.708,-.05],[.059,.163,.043],'Flexes the knee and extends the hip.'),('Gastrocnemius',[.105,.317,-.038],[.048,.12,.042],'Raises the heel during walking and jumping.'),('Tibialis anterior',[.083,.31,.034],[.027,.133,.023],'Lifts the foot at the ankle.'),('Gluteus maximus',[.079,.919,-.078],[.077,.09,.045],'Extends the hip.'),('Latissimus dorsi',[.104,1.268,-.094],[.073,.14,.028],'Pulls the arm down and back.')]:ell(label+' '+name,[side*c[0],c[1],c[2]],s,'Muscles',desc)
 for j in range(3):ell(label+' rectus abdominis '+str(j+1),[side*.038,1.06+j*.059,.10],[.032,.026,.022],'Muscles','Flexes the trunk and supports the abdominal wall.')
 ell(label+' lung',[side*.083,1.367,.025],[.068,.108,.062],'Respiratory','Exchanges oxygen and carbon dioxide between air and blood.')
 ell(label+' kidney',[side*.079,1.115,-.036],[.035,.057,.025],'Urinary','Filters blood and helps regulate fluid balance.')
bone('Neck support',[0,1.51,0],[0,1.61,0],.037)
ell('Trachea',[0,1.51,.045],[.016,.079,.015],'Respiratory','Conducts air toward the bronchi and lungs.')
ell('Heart',[.031,1.315,.063],[.046,.065,.042],'Circulatory','Pumps blood through the pulmonary and systemic circulations.')
ell('Liver',[-.063,1.212,.038],[.105,.046,.066],'Digestive','Processes nutrients, produces bile, and performs many metabolic functions.')
ell('Stomach',[.072,1.184,.054],[.052,.065,.036],'Digestive','Stores and mixes food with digestive secretions.')
ell('Spleen',[.13,1.205,-.015],[.024,.05,.028],'Organs','Filters blood and supports immune function.')
ell('Pancreas',[.022,1.153,-.005],[.071,.018,.02],'Digestive','Produces digestive enzymes and hormones including insulin.')
ell('Urinary bladder',[0,.963,.052],[.041,.041,.031],'Urinary','Stores urine before it leaves the body.')
for j in range(6):ell('Small intestine loop '+str(j+1),[(-1 if j%2 else 1)*.02,1.025+j*.019,.055],[.063,.012,.026],'Digestive','Absorbs most nutrients from digested food; loops are schematic.')
for name,c,s in [('Ascending colon',[-.097,1.074,.043],[.018,.082,.021]),('Descending colon',[.097,1.074,.043],[.018,.082,.021]),('Transverse colon',[0,1.144,.068],[.103,.016,.023])]:ell(name,c,s,'Digestive','Absorbs water and moves remaining digestive contents toward elimination.')
# Binary glTF with individually named meshes, metadata and a portable explode animation.
blob=bytearray();views=[];acc=[];meshes=[];nodes=[];mats=[]
def buf(vals,fmt,typ,component,targets=None):
 while len(blob)%4:blob.append(0)
 off=len(blob);blob.extend(struct.pack('<'+fmt*len(vals),*vals));views.append({'buffer':0,'byteOffset':off,'byteLength':len(blob)-off});d={'bufferView':len(views)-1,'componentType':component,'count':len(vals)//({'VEC3':3,'SCALAR':1}[typ]),'type':typ}
 if typ=='VEC3':d.update(min=[min(vals[i::3]) for i in range(3)],max=[max(vals[i::3]) for i in range(3)])
 if targets:d.update(targets)
 acc.append(d);return len(acc)-1
for p in parts:
 rgb=[int(p['color'][i:i+2],16)/255 for i in (1,3,5)];mats.append({'name':p['system'],'pbrMetallicRoughness':{'baseColorFactor':rgb+[1],'metallicFactor':.05,'roughnessFactor':.65},'doubleSided':True})
 meshes.append({'name':p['name'],'primitives':[{'attributes':{'POSITION':buf(p['v'],'f','VEC3',5126),'NORMAL':buf(p['n'],'f','VEC3',5126)},'indices':buf(p['i'],'H','SCALAR',5123),'material':len(mats)-1}]})
 nodes.append({'name':p['name'],'mesh':len(meshes)-1,'extras':{k:p[k] for k in ['system','description','offset']}})
tm=buf([0,2,4,6],'f','SCALAR',5126,{'min':[0],'max':[6]});sam=[];channels=[]
for j,p in enumerate(parts):
 out=buf([0,0,0]+p['offset']+p['offset']+[0,0,0],'f','VEC3',5126);sam.append({'input':tm,'output':out,'interpolation':'LINEAR'});channels.append({'sampler':j,'target':{'node':j,'path':'translation'}})
g={'asset':{'version':'2.0','generator':'Anatomy Explorer — procedural educational model'},'scene':0,'scenes':[{'nodes':list(range(len(nodes)))}],'nodes':nodes,'meshes':meshes,'materials':mats,'buffers':[{'byteLength':len(blob)}],'bufferViews':views,'accessors':acc,'animations':[{'name':'Explode and reassemble','samplers':sam,'channels':channels}]}
j=json.dumps(g,separators=(',',':')).encode();j+=b' '*((-len(j))%4);blob+=b'\0'*((-len(blob))%4);glb=struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(blob))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(blob),0x004e4942)+blob
(P/'human-anatomy.glb').write_bytes(glb)
(P/'data.json').write_text(json.dumps([{k:v for k,v in p.items() if k not in ['v','n','i']} for p in parts]))
(P/'model-b64.txt').write_text(base64.b64encode(glb).decode())
print(len(parts),'parts;',len(glb),'GLB bytes')
