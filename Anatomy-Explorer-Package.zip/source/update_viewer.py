from pathlib import Path
import json,base64,zipfile
p=Path(__file__).parent;o=p/'combined'
s=(p/'viewer-template.html').read_text()
s=s.replace('Anatomy Explorer','Human + Machine').replace('INTERACTIVE / 3D ATLAS','ANATOMY / HUMAN + MOTORCYCLE').replace('125 individual pieces','195 individual pieces').replace('The human body','Human + adventure motorcycle')
s=s.replace('Zoom in to separate the anatomy. Hover over a piece, or click to keep its description selected.','125 human parts + 70 motorcycle components. Zoom to separate both models. Hover or click a piece to learn its function.')
s=s.replace('<label for="explode">','<label for="subject">EXPLORE</label><select id="subject" aria-label="Model"><option value="Both">Human + motorcycle</option><option value="Human">Human anatomy</option><option value="Motorcycle">Motorcycle anatomy</option></select><label for="explode">')
s=s.replace('<div class="row">','<select id="partlist" aria-label="Select a component"><option value="-1">Find a component…</option></select><div class="row">')
s=s.replace('Stylized educational anatomy · Representative structures<br>Simplified shapes and counts; not a complete medical atlas.','BMW R 1250 GS Adventure–inspired motorcycle<br>Stylized anatomy and mechanics · Not medical or factory CAD.')
s=s.replace('let yaw=0,pitch=.03,distance=2.8','let yaw=0,pitch=.10,distance=5.5')
s=s.replace("const system=document.querySelector('#system'),slider=document.querySelector('#explode');for(let s of [...new Set(parts.map(p=>p.extras.system))])system.add(new Option(s,s));", """const system=document.querySelector('#system'),slider=document.querySelector('#explode'),subject=document.querySelector('#subject'),partlist=document.querySelector('#partlist');
+function populate(){system.innerHTML='<option value="All">All systems</option>';for(let s of [...new Set(parts.filter(p=>subject.value==='Both'||p.extras.object===subject.value).map(p=>p.extras.system))])system.add(new Option(s,s));populateParts()}
+function populateParts(){partlist.innerHTML='<option value="-1">Find a component…</option>';for(let p of parts.filter(p=>(subject.value==='Both'||p.extras.object===subject.value)&&(system.value==='All'||system.value===p.extras.system)))partlist.add(new Option(p.extras.object+' · '+p.name,p.id))}populate();
+function base(){return subject.value==='Both'?5.5:subject.value==='Human'?2.8:3.7}function center(){return subject.value==='Both'?0:subject.value==='Human'?-1.5:.85}
+""".replace('\n+','\n'))
s=s.replace('distance+explode*1.25','distance+explode*1.7').replace('[d*sy*cp,.95+d*sp,d*cy*cp]','[center()+d*sy*cp,.95+d*sp,d*cy*cp]')
s=s.replace("if(system.value!=='All'&&system.value!==p.extras.system)continue;","if((subject.value!=='Both'&&subject.value!==p.extras.object)||(system.value!=='All'&&system.value!==p.extras.system))continue;")
s=s.replace("system.onchange=()=>{locked=-1;hover=-1}","system.onchange=()=>{locked=-1;hover=-1;populateParts()};subject.onchange=()=>{locked=-1;hover=-1;distance=base();change(0);populate()};partlist.onchange=()=>{locked=+partlist.value;describe(locked);if(locked>=0)change(.8)}")
s=s.replace('Math.max(1.7,Math.min(3.6,distance+e.deltaY*.0015))','Math.max(base()*.64,Math.min(base()*1.3,distance+e.deltaY*.002)))'.rstrip(')')+')') if False else s
s=s.replace('Math.max(1.7,Math.min(3.6,distance+e.deltaY*.0015))','Math.max(base()*.64,Math.min(base()*1.3,distance+e.deltaY*.002))')
s=s.replace('Math.max(1.7,Math.min(3.6,distance-(d-pinch)*.008))','Math.max(base()*.64,Math.min(base()*1.3,distance-(d-pinch)*.008))')
s=s.replace('(2.8-distance)/1.1','(base()-distance)/(base()*.36)')
s=s.replace("yaw=0;pitch=.03;distance=2.8;change(0);system.value='All';locked=-1;hover=-1","yaw=0;pitch=.10;distance=base();change(0);system.value='All';locked=-1;hover=-1;populateParts()")
s=s.replace("textContent=p.extras.system","textContent=p.extras.object+' / '+p.extras.system")
s=s.replace("a.download='human-anatomy.glb'","a.download='Human-and-Motorcycle.glb'")
s=s.replace("gl.disable(gl.CULL_FACE);","gl.disable(gl.CULL_FACE);if(pick)gl.disable(gl.DITHER);else gl.enable(gl.DITHER);")
s=s.replace('width:290px','width:290px;max-height:55vh;overflow:auto').replace('max-width:300px;text-align:right','max-width:370px;text-align:right')
s=s.replace('__MODEL__',base64.b64encode((o/'Human-and-Motorcycle.glb').read_bytes()).decode())
# Preserve original viewer identity on writeback; new local folder contains the updated version.
(o/'Anatomy-Explorer.html').write_text(s)
(o/'check.js').write_text(s.split('<script>')[1].split('</script>')[0])
(o/'README.txt').write_text('''HUMAN + MACHINE — INTERACTIVE 3D ANATOMY

Open Anatomy-Explorer.html in desktop Chrome. This offline file contains the complete model; no installation or web server is needed. Enable WebGL if required by your browser.

The human (125 pieces) and a BMW R 1250 GS Adventure-inspired motorcycle (70 components) appear side by side. Scroll inward to separate parts, outward to reassemble. Drag to orbit; hover for names and functions; click to keep the description selected. Use Explore to focus on a model, All systems to filter, and Find a component to select by name. The slider controls separation directly. Reset view reassembles the selected view. On touchscreens, pinch to zoom and tap to select.

Human-and-Motorcycle.glb contains 195 named meshes and an Explode and reassemble animation. Node extras contain object, system, description and offset. Standard animation-capable GLB viewers can play the animation. Automatic zoom explosion and hover labels require the supplied HTML viewer.

This is original, schematic educational artwork. The human retains the previous simplified anatomy. The motorcycle is an R 1250 GS Adventure-inspired interpretation, not official BMW CAD, an exact model-year replica, or a repair guide. Its internal mechanisms, dimensions and details are simplified. Windscreen is opaque blue for reliable rendering. Both models are approximately proportioned, not dimensionally certified.

Reference for motorcycle architecture: BMW Media Information, November 2018, The new BMW R 1250 R, R 1250 RS and R 1250 GS Adventure:
https://www.invelt.com/UserFiles/File/1667732004The-new-BMW-R-1250-R-the-new-BMW-R-1250-RS-and-the-new-BMW-R-1250-GS-Adventure-2.PDF
BMW Telelever explanation:
https://www.bmwmotorcycles.com/en/engineering/detail/suspension/telelever.html

Source: build.py is the original human generator. add_motorcycle.py builds the combined model using Python standard library. update_viewer.py creates the updated viewer using viewer-template.html. Place source files together and run add_motorcycle.py followed by update_viewer.py; output appears in combined/.
''')
with zipfile.ZipFile(o/'Anatomy-Explorer-Package.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in ['Human-and-Motorcycle.glb','Anatomy-Explorer.html','README.txt','components.json']:z.write(o/f,f)
 for f in ['build.py','add_motorcycle.py','update_viewer.py','viewer-template.html']:z.write(p/f,'source/'+f)
print('Viewer and package built')
